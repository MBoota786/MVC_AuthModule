﻿namespace Webgentle.BookStore.Repository
{
    public interface IMessageRepository
    {
        string GetName();
    }
}